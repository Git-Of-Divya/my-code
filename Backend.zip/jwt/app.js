const bodyParser = require('body-parser');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const port = 3000;
const userRouter = require('./router/userRouter');
const productRouter = require('./router/productRouter');
const cors = require('cors');

app.use(cors());
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

mongoose.connect('mongodb+srv://divya:awantika12345@cluster0.ooldz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority')
.then(result=>{
       console.log("Database connected...");
       app.use("/user",userRouter);
       app.use("/product",productRouter);
       app.listen(port,(err)=>{
       err?console.log(err):console.log("server started on port"+port);
    });
})
.catch(err=>{
    console.log("Database not connected...");
})

